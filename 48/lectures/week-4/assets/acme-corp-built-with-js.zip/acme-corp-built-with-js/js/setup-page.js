var body = document.querySelector("body");

// Create the <header> and append it to the body...
var header = document.createElement("header");
body.appendChild(header);

// You do the rest...
